# OneIndex-moe-theme
一个对 OneIndex 自带 nexmoe 主题的修改

## 使用方法
1. 在 OneIndex 的目录下的 view 文件夹中新建一个文件夹
2. 将文件全部拷贝进去
3. 在后台主题选项中选择新建的文件夹名称并保存

## Todo
美化密码输入界面
