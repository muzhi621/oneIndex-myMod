# OneIndex-theme
OneIndex 自带主题 nexmoe 的美化修改

## 修改了什么

1. 常规美化
2. 对于flac格式音乐加入图标显示

## 如何使用

由于主题包内引用了外部文件，需要根据你的实际情况修改一下，

1. 找到 `nexmoe` 下 `layout.php` 使用打开

    修改 第7行 、第9行 第18行 yun.zhebk.cn 为自己域名（或者自己引用的目录）

    修改 第15行 链接里的QQ 为自己QQ（或者自己引用的图片）
    
2. 打开 `theme` 下 `style.css` 文件

    修改 第97行、第103行 `yun.zhebk.cn` 为自己域名（或者自己引用的目录）

    请删除原有 `nexmoe` 主题文件夹，将压缩包内 `nexmoe` 复制到该位置。

3. 将 `theme` 文件夹放在网站根目录.（或者别的地方，可以引用就好）

## 演示地址
请访问：https://yun.zhebk.cn
